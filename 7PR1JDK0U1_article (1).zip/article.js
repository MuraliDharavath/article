// Select DOM elements
const articleInput = document.getElementById("articleInput");
const summarizeButton = document.getElementById("summarizeButton");
const summaryOutput = document.getElementById("summaryOutput");

// Simple summarization function
function summarizeArticle(text) {
    // Split into sentences
    const sentences = text.split(/[.!?]\s+/);
    const sentenceCount = Math.ceil(sentences.length * 0.3); // Take 30% of sentences

    // Create a map of sentence importance (naive method)
    const wordCounts = {};
    text.split(/\s+/).forEach(word => {
        word = word.toLowerCase().replace(/[^a-z]/g, "");
        if (word) wordCounts[word] = (wordCounts[word] || 0) + 1;
    });

    const rankedSentences = sentences
        .map(sentence => {
            const words = sentence.split(/\s+/);
            const importance = words.reduce((acc, word) => {
                word = word.toLowerCase().replace(/[^a-z]/g, "");
                return acc + (wordCounts[word] || 0);
            }, 0);
            return {
                sentence,
                importance
            };
        })
        .sort((a, b) => b.importance - a.importance);

    // Take top-ranked sentences
    return rankedSentences.slice(0, sentenceCount).map(item => item.sentence).join(". ") + ".";
}

// Event listener for summarizing
summarizeButton.addEventListener("click", () => {
    const articleText = articleInput.value.trim();
    if (!articleText) {
        summaryOutput.textContent = "Please enter some text to summarize.";
        return;
    }
    const summary = summarizeArticle(articleText);
    summaryOutput.textContent = summary;
});